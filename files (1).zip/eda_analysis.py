"""
SWYNEX - Exploratory Data Analysis (Retail Sales)

Generates 4 charts into the charts/ folder.
- If retail_sales_clean.csv exists, it is used (needs columns:
  date, category, region, quantity, unit_price, sales).
- Otherwise SAMPLE (synthetic) data is created so the charts can be previewed.
Replace the sample CSV with your real data to get real charts.
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

CSV = "retail_sales_clean.csv"
os.makedirs("charts", exist_ok=True)

# ---------- Load or create data ----------
if os.path.exists(CSV):
    df = pd.read_csv(CSV, parse_dates=["date"])
    note = ""
else:
    rng = np.random.default_rng(42)
    n = 1500
    dates = pd.to_datetime("2025-01-01") + pd.to_timedelta(rng.integers(0, 365, n), unit="D")
    cats = rng.choice(["Electronics", "Clothing", "Grocery", "Home", "Beauty"], n,
                      p=[0.2, 0.25, 0.3, 0.15, 0.1])
    regions = rng.choice(["North", "South", "East", "West"], n)
    qty = rng.integers(1, 8, n)
    base = {"Electronics": 300, "Clothing": 60, "Grocery": 15, "Home": 90, "Beauty": 35}
    price = np.array([base[c] for c in cats]) * rng.uniform(0.8, 1.3, n)
    season = 1 + 0.25 * np.isin(dates.month, [11, 12])
    df = pd.DataFrame({"date": dates, "category": cats, "region": regions,
                       "quantity": qty, "unit_price": price.round(2)})
    df["sales"] = (df.quantity * df.unit_price * season).round(2)
    df.sort_values("date").to_csv(CSV, index=False)
    note = " (sample data)"

df["month"] = df["date"].dt.to_period("M").dt.to_timestamp()
plt.rcParams.update({"figure.dpi": 130, "axes.spines.top": False, "axes.spines.right": False})

# ---------- 1. Monthly sales trend ----------
m = df.groupby("month")["sales"].sum()
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.plot(m.index, m.values, marker="o", color="#2a6fdb")
ax.set(title="Monthly Sales Trend" + note, xlabel="Month", ylabel="Total sales")
fig.autofmt_xdate(); fig.tight_layout()
fig.savefig("charts/1_monthly_sales_trend.png"); plt.close(fig)

# ---------- 2. Sales by category ----------
c = df.groupby("category")["sales"].sum().sort_values()
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.barh(c.index, c.values, color="#2fa37a")
ax.set(title="Total Sales by Category" + note, xlabel="Total sales")
fig.tight_layout(); fig.savefig("charts/2_sales_by_category.png"); plt.close(fig)

# ---------- 3. Sales distribution ----------
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.hist(df["sales"], bins=40, color="#e08a1e", edgecolor="white")
ax.axvline(df["sales"].median(), color="black", ls="--", label=f"Median: {df['sales'].median():.0f}")
ax.set(title="Distribution of Sales per Transaction" + note, xlabel="Sales", ylabel="Transactions")
ax.legend(); fig.tight_layout()
fig.savefig("charts/3_sales_distribution.png"); plt.close(fig)

# ---------- 4. Sales by region and category ----------
p = df.pivot_table(index="region", columns="category", values="sales", aggfunc="sum")
fig, ax = plt.subplots(figsize=(8, 4.5))
p.plot(kind="bar", stacked=True, ax=ax, colormap="tab20c")
ax.set(title="Sales by Region and Category" + note, xlabel="Region", ylabel="Total sales")
plt.xticks(rotation=0); ax.legend(title="Category", fontsize=8)
fig.tight_layout(); fig.savefig("charts/4_sales_by_region.png"); plt.close(fig)

print("Done: 4 charts saved in charts/")
